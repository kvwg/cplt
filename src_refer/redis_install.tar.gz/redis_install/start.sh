#!/bin/bash

redis-server redis.conf

