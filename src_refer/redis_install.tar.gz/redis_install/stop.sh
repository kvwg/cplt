#!/bin/bash

redis-cli shutdown
